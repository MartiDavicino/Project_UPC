_______________________________________________________________________________________________

PANG!/Buster Bros!

By Los Merlaos:

Github : https://github.com/MartiDavicino/Project_UPC

GROUP MEMBERS:

- Martí Davicino -Gh: https://github.com/MartiDavicino
- Otto Tolo -Gh: https://github.com/ottotolo
- Adrí Castelló -Gh: https://github.com/AdriTrabajador
- Aitor Álvarez -Gh: https://github.com/AitorAlvarez17

_______________________________________________________________________________________________


Pang also known as Pomping World is an arcade game released in 1989 by Mitchell Corporation. 
The plot of the game is about two players, the brothers called Busters, who collaborate
to destroy the bubbles. The brothers have to go around the world destroying jumping bubbles 
that are terrorizing various cities on Earth.

_______________________________________________________________________________________________

HOW TO PLAY:

A - Move left.
D - Mode Right.
Space - confirm / shoot.
G - debug mode.
F1 - Draw hitboxes

Enjoy!

